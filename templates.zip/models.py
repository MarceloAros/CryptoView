from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

#class nombre de mi modelo 